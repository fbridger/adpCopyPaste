addHoliday("uy", 2017, 2,  27, "Carnaval");
addHoliday("uy", 2017, 2,  28, "Carnaval");

addHoliday("uy", 2017, 4, 14,  "Viernes Santo");
