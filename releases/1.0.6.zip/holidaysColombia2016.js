var co2016 = [{
    "dia": 7,
    "mes": 11,
    "motivo": "Todos los Santos",
    "tipo": "inamovible"
}, {
    "dia": 14,
    "mes": 11,
    "motivo": "Independencia de Cartagena",
    "tipo": "inamovible"
}, {
    "dia": 8,
    "mes": 12,
    "motivo": "Día de la Inmaculada Concepción",
    "tipo": "inamovible"
}, {
    "dia": 25,
    "mes": 12,
    "motivo": "Navidad",
    "tipo": "inamovible"
}];

addHolidays("co", 2016, co2016);