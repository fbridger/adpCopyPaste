
addHoliday("ar", 2017, 2,  27, "Carnaval");
addHoliday("ar", 2017, 2,  28, "Carnaval");

addHoliday("ar", 2017, 4, 13,  "Jueves Santo");
addHoliday("ar", 2017, 4, 14,  "Viernes Santo");

addHoliday("ar", 2017, 6, 17,  "Paso a la Inmortalidad del Gral. Don Martín Güemes", "nolaborable");
addHoliday("ar", 2017, 6, 19,  "Feriado Puente Turistico", "puente");

addHoliday("ar", 2017, 8, 17, "Paso a la Inmortalidad del General José de San Martín", "trasladable", 14);
addHoliday("ar", 2017, 10,12, "Día del Respeto a la Diversidad Cultural", "trasladable", 9);
addHoliday("ar", 2017, 11,20, "Día de la Soberanía Nacional",	"trasladable", 27);
