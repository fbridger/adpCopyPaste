
var ar2017 =[{
	"dia": 1,
	"mes": 1 ,
	"motivo": "Año nuevo",
	"tipo": "inamovible"
},{
	"dia": 27,
	"mes": 2,
	"motivo": "Carnaval",
	"tipo": "inamovible"
},{
	"dia": 28,
	"mes": 2,
	"motivo": "Carnaval",
	"tipo": "inamovible"
},{
	"dia": 24,
	"mes": 3,
	"motivo": "Día Nacional de la Memoria por la Verdad y la Justicia.",
	"tipo": "inamovible"
},{
	"dia": 13,
	"mes": 4,
	"motivo": "Jueves Santo",
	"tipo": "inamovible"
},{
	"dia": 14,
	"mes": 4,
	"motivo": "Jueves Santo",
	"tipo": "inamovible"
},{
	"dia": 1,
	"mes": 5,
	"motivo": "Día del trabajador",
	"tipo": "inamovible"
},{
	"dia": 25,
	"mes": 5,
	"motivo": "Día de la Revolución de Mayo",
	"tipo": "inamovible"
},{
	"dia": 17,
	"mes": 6,
	"motivo": "Paso a la Inmortalidad del Gral. Don Martín Güemes",
	"tipo": "nolaborable"
},{
	"dia": 19,
	"mes": 6 ,
	"motivo": "Feriado Puente Turistico",
	"tipo": "puente"
},{
	"dia": 20,
	"mes": 6,
	"motivo": "Día Paso a la Inmortalidad del General Manuel Belgrano",
	"tipo": "nolaborable"
},{
	"dia": 9,
	"mes": 7,
	"motivo": "Día de la Independencia",
	"tipo": "nolaborable"
},{
	"dia": 17,
	"mes": 8 ,
	"motivo": "Paso a la Inmortalidad del General José de San Martín",
	"tipo": "trasladable",
	"traslado": 14
},{
	"dia": 12,
	"mes": 10,
	"motivo": "Día del Respeto a la Diversidad Cultural",
	"tipo": "trasladable",
	"traslado": 9
},{
	"dia": 20,
	"mes": 11,
	"motivo": "Día de la Soberanía Nacional",
	"tipo": "trasladable",
	"traslado": 27
},{
	"dia": 8,
	"mes": 12 ,
	"motivo": "Inmaculada Concepción de María",
	"tipo": "inamovible"
},{
	"dia": 25,
	"mes": 12 ,
	"motivo": "Navidad",
	"tipo": "inamovible"
}];

addHolidays("ar", 2017, ar2017);