function getGridTable() {
    return this.tcmGridTableSelector || (this.tcmGridTableSelector = $("#TCMGridTable"))
}