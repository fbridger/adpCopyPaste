addFixedHoliday("ve", 1,  1,  "Año Nuevo");

addFixedHoliday("ve", 4,  19,  "Declaración de la Independencia");
addFixedHoliday("ve", 5,  1, "Día del Trabajo");
addFixedHoliday("ve", 6,  24,  "Batalla de Carabobo");
addFixedHoliday("ve", 7,  5,  "Día de la Independencia");
addFixedHoliday("ve", 7,  24,  "Natalicio de Simón Bolívar");
addFixedHoliday("ve", 10,  12,  "Día de la Resistencia Indígena");

addFixedHoliday("ve", 12, 8,  "Inmaculada Concepción de María");
addFixedHoliday("ve", 12, 24, "Víspera de Navidad");
addFixedHoliday("ve", 12, 25, "Navidad");
addFixedHoliday("ve", 12, 31, "Fiesta de Fin de Año");