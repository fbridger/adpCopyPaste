
var ar2016 =[{
	"dia": 8,
	"mes": 2 ,
	"motivo": "Carnaval",
	"tipo": "inamovible"
},{
	"dia": 9,
	"mes": 2 ,
	"motivo": "Carnaval",
	"tipo": "inamovible"
},{
	"dia": 25,
	"mes": 3,
	"motivo": "Viernes Santo",
	"tipo": "inamovible"
},{
	"dia": 17,
	"mes": 6,
	"motivo": "Paso a la Inmortalidad del Gral. Don Martín Güemes",
	"tipo": "nolaborable"
},{
	"dia": 8,
	"mes": 7 ,
	"motivo": "Feriado Puente Turistico",
	"tipo": "puente"
},{
	"dia": 17,
	"mes": 8 ,
	"motivo": "Paso a la Inmortalidad del General José de San Martín",
	"tipo": "trasladable",
	"traslado": 15
},{
	"dia": 12,
	"mes": 10,
	"motivo": "Día del Respeto a la Diversidad Cultural",
	"tipo": "trasladable",
	"traslado": 10
},{
	"dia": 20,
	"mes": 11,
	"motivo": "Día de la Soberanía Nacional",
	"tipo": "trasladable",
	"traslado": 28
},{
	"dia": 9,
	"mes": 12 ,
	"motivo": "Feriado Puente Turistico",
	"tipo": "puente"
},{
	"dia": 8,
	"mes": 12 ,
	"motivo": "Inmaculada Concepción de María",
	"tipo": "inamovible"
},{
	"dia": 22,
	"mes": 4 ,
	"motivo": "Pascuas Judías",
	"tipo": "nolaborable",
	"opcional": {
		"tipo": "religion",
		"religion": "judaísmo"
	}
},{
	"dia": 23,
	"mes": 4 ,
	"motivo": "Pascuas Judías",
	"tipo": "nolaborable",
	"opcional": {
		"tipo": "religion",
		"religion": "judaísmo"
	}
},{
	"dia": 24,
	"mes": 4 ,
	"motivo": "Pascuas Judías",
	"tipo": "nolaborable",
	"opcional": {
		"tipo": "religion",
		"religion": "judaísmo"
	}
},{
	"dia": 28,
	"mes": 4 ,
	"motivo": "Pascuas Judías",
	"tipo": "nolaborable",
	"opcional": {
		"tipo": "religion",
		"religion": "judaísmo"
	}
},{
	"dia": 29,
	"mes": 4 ,
	"motivo": "Pascuas Judías",
	"tipo": "nolaborable",
	"opcional": {
		"tipo": "religion",
		"religion": "judaísmo"
	}
},{
	"dia": 30,
	"mes": 4 ,
	"motivo": "Pascuas Judías",
	"tipo": "nolaborable",
	"opcional": {
		"tipo": "religion",
		"religion": "judaísmo"
	}
},{
	"dia": 4,
	"mes": 10 ,
	"motivo": "Año Nuevo Judío",
	"tipo": "nolaborable",
	"opcional": {
		"tipo": "religion",
		"religion": "judaísmo"
	}
},{
	"dia": 12,
	"mes": 10 ,
	"motivo": "Día del Perdón",
	"tipo": "nolaborable",
	"opcional": {
		"tipo": "religion",
		"religion": "judaísmo"
	}
},{
	"dia": 25,
	"mes": 12,
	"motivo": "Navidad",
	"tipo": "inamovible"
}];

addHolidays("ar", 2016, ar2016);