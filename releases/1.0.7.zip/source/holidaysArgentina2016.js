
addHoliday("ar", 2016, 2, 8,  "Carnaval");
addHoliday("ar", 2016, 2, 9,  "Carnaval");
addHoliday("ar", 2016, 3, 25, "Viernes Santo");
addHoliday("ar", 2016, 6, 17, "Paso a la Inmortalidad del Gral. Don Martín Güemes", "nolaborable");
addHoliday("ar", 2016, 7, 8,  "Feriado Puente Turistico", "puente");
addHoliday("ar", 2016, 8, 17, "Paso a la Inmortalidad del General José de San Martín", "trasladable", 15);
addHoliday("ar", 2016, 10,12, "Día del Respeto a la Diversidad Cultural", "trasladable", 10);
addHoliday("ar", 2016, 11,20, "Día de la Soberanía Nacional", "trasladable", 28);
addHoliday("ar", 2016, 12, 9, "Feriado Puente Turistico", "puente");
addHoliday("ar", 2016, 4, 22, "Pascuas Judías", "nolaborable", undefined,{ "tipo": "religion", "religion": "judaísmo"});
addHoliday("ar", 2016, 4, 23, "Pascuas Judías", "nolaborable", undefined,{ "tipo": "religion", "religion": "judaísmo"});
addHoliday("ar", 2016, 4, 24, "Pascuas Judías", "nolaborable", undefined,{ "tipo": "religion", "religion": "judaísmo"});
addHoliday("ar", 2016, 4, 28, "Pascuas Judías", "nolaborable", undefined,{ "tipo": "religion", "religion": "judaísmo"});
addHoliday("ar", 2016, 4, 29, "Pascuas Judías", "nolaborable", undefined,{ "tipo": "religion", "religion": "judaísmo"});
addHoliday("ar", 2016, 4, 30, "Pascuas Judías", "nolaborable", undefined,{ "tipo": "religion", "religion": "judaísmo"});
addHoliday("ar", 2016, 10, 4, "Año Nuevo Judío","nolaborable", undefined,{ "tipo": "religion", "religion": "judaísmo"});
addHoliday("ar", 2016, 10, 12,"Día del Perdón", "nolaborable", undefined,{ "tipo": "religion", "religion": "judaísmo"});
