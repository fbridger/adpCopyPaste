addFixedHoliday("uy", 1,  1,  "Año Nuevo");

addFixedHoliday("uy", 5,  1,  "Día de los Trabajadores");
addFixedHoliday("uy", 7,  18, "Jura de la Constitución");
addFixedHoliday("uy", 8,  25,  "Día de la Independencia Nacional");

addFixedHoliday("uy", 12, 25, "Navidad");